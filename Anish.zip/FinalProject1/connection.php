<?php
   $conn= mysqli_connect("localhost","root","","product");
   if(!($conn)){
    echo"connection is stablished";
   }
?>